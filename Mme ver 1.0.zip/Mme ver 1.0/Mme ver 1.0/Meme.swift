//
//  Meme.swift
//  Mme ver 1.0
//
//  Created by Mac on 12/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    
    var topText: String!
    var bottomText: String!
    var originalImage: UIImage!
    var memedImage: UIImage!
}
