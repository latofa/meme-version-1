//
//  ViewController.swift
//  Mme ver 1.0
//
//  Created by Mac on 09/03/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate   {
    
    let pickerController = UIImagePickerController()
    
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var imagePickerView: UIImageView!
    @IBOutlet weak var topToolbar: UIToolbar!
    @IBOutlet weak var bottomToolBar: UIToolbar!
    @IBOutlet weak var aboveText: UITextField!
    @IBOutlet weak var bottomText: UITextField!
    var finalImage : UIImage = UIImage()
    let  textDelegate = textFieldDelegate()
    
    
    let memeTextAttributes:[NSAttributedString.Key: Any] = [
        NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeColor.rawValue): UIColor.black /* TODO: fill in appropriate UIColor */,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue): UIColor.white/* TODO: fill in appropriate UIColor */,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeWidth.rawValue): Float.init(-4.0) /* TODO: fill in appropriate Float */]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureTextfield(textfield: aboveText , withText: "TOP")
        configureTextfield(textfield: bottomText , withText: "BOTTOM")
        
        //disbling share button
        shareButton.isEnabled = false
        
        //disabling camera button if device not support using camera
        if  !UIImagePickerController.isSourceTypeAvailable(.camera){
            
            cameraButton.isEnabled = false
        }
        
    }
    
    func configureTextfield(textfield: UITextField , withText:String) {
        textfield.delegate = textDelegate
        textfield.defaultTextAttributes = memeTextAttributes
        textfield.textAlignment = .center
        textfield.text = withText
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        
        view.frame.origin.y = 0
    }
    
    @objc func keyboardWillShow(_ notification:Notification) {
        
        if bottomText.isFirstResponder {
            view.frame.origin.y = -getKeyboardHeight(notification)
        }
        
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    
    @IBAction func pickImage(_ sender: Any) {
        
        pickerController.delegate = self
        let button = sender as! UIButton
        
        // if request using album
        if (button.tag == 0){
            
            pickerController.allowsEditing=false
            pickerController.sourceType = .photoLibrary
            
            //request using camera
        }else{
            
            pickerController.sourceType = .camera
            
        }
        
        present(pickerController, animated: true, completion: nil)
        
        
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        // here we check if the request for album or camera
        if picker.sourceType == .camera {
            
            print("camera")
            dismiss(animated: true, completion: nil)
            imagePickerView.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
            
        }else{
            
            if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                imagePickerView.contentMode = .scaleAspectFit
                
                
                imagePickerView.image = pickedImage
                
                
                shareButton.isEnabled = true
                
            }
            
            dismiss(animated: true, completion: nil)
        }
        
        
        
    }
    
    // this is optional dimiss if oressed cancell 
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func generateMemedImage() -> UIImage {
        
        // TODO: Hide toolbar and navbar
        configureBars(true)
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        self.finalImage = memedImage
        
        // TODO: Show toolbar and navbar
        configureBars(false)
        return memedImage
    }
    
    func configureBars(_ isHidden: Bool) {
        bottomToolBar.isHidden = isHidden
        topToolbar.isHidden = isHidden
    }
    
    @IBAction func shareImage(_ sender: Any){
        
        let generateImage :UIImage =  generateMemedImage()
        
        
        
        let activityViewController = UIActivityViewController(activityItems: [generateImage],applicationActivities: nil)
        
        present(activityViewController, animated: true)
        activityViewController.completionWithItemsHandler = {
            (activity, completed, items, error) in
            if (completed){
                self.save(memedImage: generateImage)
            }
        }
        
    }
    
    func save (memedImage: UIImage){
        
        // Create the meme
        let meme = Meme(topText: aboveText.text, bottomText: bottomText.text, originalImage: imagePickerView.image, memedImage: finalImage)
    }
    
    
}

